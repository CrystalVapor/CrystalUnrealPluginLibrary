﻿#include "EquipmentSystemEditor.h"

#define LOCTEXT_NAMESPACE "FEquipmentSystemEditorModule"

void FEquipmentSystemEditorModule::StartupModule()
{
    
}

void FEquipmentSystemEditorModule::ShutdownModule()
{
    
}

#undef LOCTEXT_NAMESPACE
    
IMPLEMENT_MODULE(FEquipmentSystemEditorModule, EquipmentSystemEditor)