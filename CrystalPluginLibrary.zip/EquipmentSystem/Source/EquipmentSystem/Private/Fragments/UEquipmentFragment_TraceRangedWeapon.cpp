﻿// Copyright 2024 CrystalVapor


#include "Fragments/EquipmentFragment_TraceRangedWeapon.h"

void UEquipmentFragment_TraceRangedWeapon::HandleChildInsideInitialize(AEquipmentInstance* Instance)
{
	Super::HandleChildInsideInitialize(Instance);
}
