﻿// Copyright 2024 CrystalVapor


#include "Fragments/EquipmentFragment_RangedWeapon.h"

#include "EquipmentInstance.h"
#include "EquipmentReplicatedPropertyManagerComponent.h"

FRAGMENT_DEFINE_PROPERTY_TAG(Damage);
FRAGMENT_DEFINE_PROPERTY_TAG(FireDelay);
FRAGMENT_DEFINE_PROPERTY_TAG(MaxDamageRange);
FRAGMENT_DEFINE_PROPERTY_TAG(WeaponSweepRadius);
FRAGMENT_DEFINE_PROPERTY_TAG(BulletsPerCartridge);
FRAGMENT_DEFINE_PROPERTY_TAG(MaxRecoilHeat);
FRAGMENT_DEFINE_PROPERTY_TAG(SpreadExponent);
FRAGMENT_DEFINE_PROPERTY_TAG(EnemyPunchThrough);
FRAGMENT_DEFINE_PROPERTY_TAG(RecoilHeatCoolDownDelay);

FRAGMENT_DEFINE_PROPERTY_TAG(HeatToSpreadCurve);
FRAGMENT_DEFINE_PROPERTY_TAG(HeatToHeatPerShotCurve);
FRAGMENT_DEFINE_PROPERTY_TAG(HeatToCoolDownPerSecondCurve)

void UEquipmentFragment_RangedWeapon::HandleChildInsideInitialize(AEquipmentInstance* Instance)
{
	Super::HandleChildInsideInitialize(Instance);
	FRAGMENT_REGISTER_FLOAT_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, Damage);
    FRAGMENT_REGISTER_FLOAT_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, FireDelay);
	FRAGMENT_REGISTER_FLOAT_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, MaxDamageRange);
	FRAGMENT_REGISTER_FLOAT_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, WeaponSweepRadius);
	FRAGMENT_REGISTER_FLOAT_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, BulletsPerCartridge);
	FRAGMENT_REGISTER_FLOAT_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, MaxRecoilHeat);
	FRAGMENT_REGISTER_FLOAT_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, SpreadExponent);
	FRAGMENT_REGISTER_FLOAT_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, EnemyPunchThrough);
	FRAGMENT_REGISTER_FLOAT_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, RecoilHeatCoolDownDelay);

	FRAGMENT_REGISTER_CURVE_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, HeatToSpreadCurve);
	FRAGMENT_REGISTER_CURVE_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, HeatToHeatPerShotCurve);
	FRAGMENT_REGISTER_CURVE_PROPERTY_GETTER(UEquipmentFragment_RangedWeapon, HeatToCoolDownPerSecondCurve);
}

void UEquipmentFragment_RangedWeapon::HandleChildFinialInitialize(AEquipmentInstance* Instance)
{
	Super::HandleChildFinialInitialize(Instance);
	//UEquipmentReplicatedPropertyManagerComponent* PropertyManager = Instance->GetReplicatedPropertyManagerComponent();
}

float UEquipmentFragment_RangedWeapon::GetCurrentRecoilHeatSpread() const
{
	return GetRecoilHeatSpreadDelegate.IsBound()? GetRecoilHeatSpreadDelegate.Execute() : 0.f;
}