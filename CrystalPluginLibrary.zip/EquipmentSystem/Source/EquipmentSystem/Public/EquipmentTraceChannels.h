// Copyright 2024 CrystalVapor

#pragma once

#define EquipmentTraceChannel_Weapon ECC_GameTraceChannel2